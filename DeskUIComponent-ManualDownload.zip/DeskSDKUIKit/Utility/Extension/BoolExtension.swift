//
//  BoolExtention.swift
//  ZohoDeskUIKit
//
//  Created by Rajeshkumar Lingavel on 14/05/18.
//  Copyright © 2018 rajesh-2098. All rights reserved.
//

import Foundation
extension Bool{
    mutating func toggle(){
        self = !self
    }
}
