//
//  DeskSDKUIKit.h
//  DeskSDKUIKit
//
//  Created by Rajeshkumar Lingavel on 10/05/18.
//  Copyright © 2018 rajesh-2098. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DeskSDKUIKit.
FOUNDATION_EXPORT double DeskSDKUIKitVersionNumber;

//! Project version string for DeskSDKUIKit.
FOUNDATION_EXPORT const unsigned char DeskSDKUIKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DeskSDKUIKit/PublicHeader.h>


